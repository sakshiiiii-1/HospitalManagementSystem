package com.hospService;

import java.sql.SQLException;
import java.util.ArrayList;

import com.entity.Doctor;
import com.hospDao.DoctorDao;
import com.hospservicerepo.HospitalRepo;

public class DocService implements HospitalRepo {

		DoctorDao rd = new DoctorDao();
		

		public void createTable(String tableName) throws SQLException {

			if (tableName != null) {
				rd.createTable(tableName);
			} else {
				System.out.println("Enter table name correctly");
			}

		}
		public void insertData(int doctorId, String docName, String docdepartment) throws SQLException{//insert
			if(doctorId!=0 && docName!=null && docdepartment!=null) {
				rd.insertData(doctorId,docName,docdepartment);
			} else {
				System.out.println("Enter data correctly");
			}

		}
		public void FetchDoctor(String tableName) throws SQLException {
			ArrayList<Doctor> plist = rd.FetchDoctor(tableName);
			plist.stream().forEach(System.out::println);
		}
		
		public void updatedoctorNamebyId(int doctorId, String docName) throws SQLException{
		    
		        if (doctorId != 0 && docName != null) {
		            rd.updatedoctorNameById(doctorId, docName);
		            System.out.println("Update successful.");
		        } else {
		            System.out.println("Invalid data. Please provide a valid doctor ID and name.");
		        }
		    
		    
		}

		public void updatedocDepartmentById(int doctorId, String docdepartment) throws SQLException{
			if(doctorId!=0 && docdepartment!=null) {
				rd.updatedocDepartmentById(doctorId,docdepartment);
			}else {
				System.out.println("Enter data correctly");
			}
		}
		public void deletebyId(int doctorId,String tableName)throws SQLException{
			if(doctorId!=0 && tableName!=null) {
				rd.deletebyId(doctorId,tableName);
			}else {
				System.out.println("Enter data correctly");
			}
		}
		public void deletebyName(String docName,String tableName)throws SQLException{
			if(docName!=null && tableName!=null) {
				rd.deletebyName(docName,tableName);
			}else {
				System.out.println("Enter data correctly");
			}
		}
		@Override
		public void updatedoctorNameById(int doctorId, String docName) throws SQLException {
			// TODO Auto-generated method stub
			
		}
//		public void updateStrValues(String tableName, String colName, String newStr, int doctorId) throws SQLException {
//			if (doctorId != 0 && colName != null && newStr != null) {
//				rd.updateStrValues(tableName, colName, newStr, doctorId);
//			} else {
//				System.out.println("Enter update table name correctly");
//			}
//		}
//		
//		public void updateNumValues(String tableName, String colName, int newNum, int doctorId) throws SQLException {
//			if (doctorId != 0 && colName != null && newNum > 0 && tableName != null) {
//				rd.updateNumValues(tableName, colName, newNum, doctorId);
//			} else {
//				System.out.println("Enter update table name correctly");
//			}
//		}
		
		
}
		
		
		
		
			
		
		
		



