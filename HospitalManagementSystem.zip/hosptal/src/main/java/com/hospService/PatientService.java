package com.hospService;

import java.sql.SQLException;
import java.util.ArrayList;

import com.entity.Patient;
import com.hospDao.PatientDao;
import com.hospservicerepo.PatientRepo;

public class PatientService implements PatientRepo {
	PatientDao pd=new PatientDao();
	
	public void CreatepTable(String tableName) throws SQLException{
		if(tableName!=null) {
			pd.CreatepTable(tableName);
		}else {
			System.out.println("Enter data correctly bro");
		}
	}
	
	public void ReportpData(int pId, String pFname ,
			String pLname,long pPhone,String pAddress,
			String DocAssign, String pDisease) throws SQLException{
		
			if(pId!=0 && pFname!=null && pLname!=null && pPhone!=0 && pAddress!=null && DocAssign!=null && pDisease!=null) {
				pd.ReportpData(pId, pFname, pLname, pPhone, pAddress, DocAssign, pDisease);
			}else {
				System.out.println("Enter data correctly bro");
			}
	}
	public void updatepNamebyid(int pId,String pFname,String pLname)throws SQLException{
		if(pId!=0 && pFname!=null && pLname!=null ) {
			pd.updatepNamebyid(pId, pFname, pLname);
		}else {
			System.out.println("Enter data correctly bro");
		}
	}
	public void deletepbyId(int pId,String tableName)throws SQLException{
		if(pId!=0 && tableName!=null ) {
			pd.deletepbyId(pId, tableName);
		}else {
			System.out.println("Enter data correctly bro");
		}
	}
	public ArrayList<Patient> getpReport(int pId) throws SQLException{
		ArrayList<Patient> plist = pd.getpReport(pId);
		plist.stream().forEach(System.out::println);
		return plist;
	}

	@Override
	public ArrayList<Patient> getReport(String tableName) throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<Patient> plist = pd.getReport(tableName);
		plist.stream().forEach(System.out::println);
		return plist;
		
		
	}
	

	

	
		
	}
	

