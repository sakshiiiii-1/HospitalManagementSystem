package com.entity;

public class Doctor {
	private int doctorId;
    private String docname;
    private String docdepartment;
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Doctor(int doctorId, String docname, String docdepartment) {
		super();
		this.doctorId = doctorId;
		this.docname = docname;
		this.docdepartment = docdepartment;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getDocname() {
		return docname;
	}
	public void setDocname(String docname) {
		this.docname = docname;
	}
	public String getDocdepartment() {
		return docdepartment;
	}
	public void setDocdepartment(String docdepartment) {
		this.docdepartment = docdepartment;
	}
	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", docname=" + docname + ", docdepartment=" + docdepartment + "]";
	}
    
    
    
//    1. New Admission
//    2. Update Patient
//    3. View Patients
//    4. Add New Doctor
//    5. View Doctors
//    6. Update Doctors
//    7. Patient Reports
//    8. Search Patient
//    0. Exit
    										
    
    
}
