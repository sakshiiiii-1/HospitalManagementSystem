package com.entity;

public class Patient {
	 private int pId;
	 private String pFname;
	 private String pLname;
	 private long pPhone;
	 private String pAddress;
	 private String DocAssign;
	 private String pDisease;
	 
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Patient(int pId, String pFname, String pLname, long pPhone, String pAddress, String docAssign,
			String pDisease) {
		super();
		this.pId = pId;
		this.pFname = pFname;
		this.pLname = pLname;
		this.pPhone = pPhone;
		this.pAddress = pAddress;
		DocAssign = docAssign;
		this.pDisease = pDisease;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getpFname() {
		return pFname;
	}

	public void setpFname(String pFname) {
		this.pFname = pFname;
	}

	public String getpLname() {
		return pLname;
	}

	public void setpLname(String pLname) {
		this.pLname = pLname;
	}

	public long getpPhone() {
		return pPhone;
	}

	public void setpPhone(long pPhone) {
		this.pPhone = pPhone;
	}

	public String getpAddress() {
		return pAddress;
	}

	public void setpAddress(String pAddress) {
		this.pAddress = pAddress;
	}

	public String getDocAssign() {
		return DocAssign;
	}

	public void setDocAssign(String docAssign) {
		DocAssign = docAssign;
	}

	public String getpDisease() {
		return pDisease;
	}

	public void setpDisease(String pDisease) {
		this.pDisease = pDisease;
	}

	@Override
	public String toString() {
		return "Patient [pId=" + pId + ", pFname=" + pFname + ", pLname=" + pLname + ", pPhone=" + pPhone
				+ ", pAddress=" + pAddress + ", DocAssign=" + DocAssign + ", pDisease=" + pDisease + "]";
	}
}
	