package com.hospDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.entity.Patient;
import com.jdbc_config.JdbcConnection;

public class PatientDao {
	static JdbcConnection connect=new JdbcConnection();
	public String CreatepTable(String tableName) throws SQLException{//to create table
		String query="create table " + tableName
				+ "(pId int primary key,"
				+ "pFname varchar(55),"
				+ "pLname varchar(20),"
				+ "pPhone long,"
				+ "pAddress varchar(20),"
				+ "DocAssign varchar(20),"
				+ "pDisease varchar(20)"+
				")";
		
		Connection con = connect.getConnection();
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		// 4 Execute Statement
		ptm.execute(query);

		System.out.println("Table created " + tableName);
		// 5 close connection
		ptm.close();
		return "table created";

	}
	public void ReportpData(int pId, String pFname , String pLname,long pPhone
			,String pAddress,String DocAssign, String pDisease) throws SQLException {//insert patient

		String query = "insert into patient Values (" + pId + ",'"
														+ pFname + "','"  
														+ pLname + "',"
														+pPhone+",'"
														+pAddress+"','"
														+DocAssign +"','"
														+ pDisease+"')";

		// 2 get connection from singleton class jdbcConnection
		Connection con = connect.getConnection();
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		// 4 Execute Statement
		ptm.execute(query);

		System.out.println("Inserted Values Successfully ");
		// 5 close connection
		ptm.close();

	}
	public void updatepNamebyid(int pId,String pFname,String pLname)throws SQLException{//update patient
		//UPDATE your_table_name
		//SET first_name = 'new_first_name', last_name = 'new_last_name'
			//	WHERE id = your_id_value;
			String query="update patient set pFname='"+pFname+"', pLname='"+pLname+"' where pId="+pId;
			// 2 get connection from singleton class jdbcConnection
			Connection con = connect.getConnection();
			// 3 Step Create Statement

			PreparedStatement ptm = con.prepareStatement(query);
			// 4 Execute Statement
			ptm.execute(query);

			System.out.println("Updated Values Successfully ");
			// 5 close connection
			ptm.close();

		
		
	}
	// public ArrayList<Patient> getReport() throws SQLException
	public ArrayList<Patient> getpReport(int pId) throws SQLException {//get report by id(search patients)

		String query = "select* from patient where pId="+pId;

		// 2 get connection from singleton class jdbcConnection
		Connection con = connect.getConnection();
		
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		// 4 Execute Statement
		ResultSet result = ptm.executeQuery();
		
		
		ArrayList<Patient> plist = new ArrayList<>();
		
		while(result.next()) {
			int pId1 = result.getInt(1);
			String pFname = result.getString(2);
			String pLname = result.getString(3);
			Long pPhone = result.getLong(4);
			String pAddress = result.getString(5);
			String DocAssign=result.getString(6);
			String pDisease=result.getString(7);
			
			
		
			Patient patient = new Patient(pId1,pFname,pLname,pPhone,pAddress,DocAssign,pDisease);
			plist.add(patient);
		}
//		for (Patient patient : plist) {
//			System.out.println("patient ID : " + result.getInt(1));
//			System.out.println("first Name : " +result.getString(2));
//			System.out.println("Last Name : " + result.getString(3));
//			System.out.println("Phone number : " + result.getLong(4));
//			System.out.println("Address : " + result.getString(5));
//			System.out.println("DocAssign : " + result.getString(6));
//			System.out.println("DocAssign : " + result.getString(7));
//			System.out.println("---------------------");

//		}
		return plist;
		
	}
	
	
	public void deletepbyId(int pId,String tableName)throws SQLException{//to delete patient by id
		String query="DELETE FROM "+tableName+" where pId="+pId;
		
		Connection con = connect.getConnection();
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		
		int rowsAffected = ptm.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Deleted Row of id :  " + pId);
        } else {
            System.out.println("No records deleted. Please check if iId exists.");
		// 4 Execute Statement
		ptm.execute(query);

		System.out.println("deleted Values Successfully ");
		// 5 close connection
		ptm.close();

       }
	}
	// public ArrayList<Patient> getReport() throws SQLException
        public ArrayList<Patient> getReport(String tableName) throws SQLException {//view patient and also to get report.

    		String query = "select * from " +tableName;

    		// 2 get connection from singleton class jdbcConnection
    		Connection con = connect.getConnection();
    		
    		// 3 Step Create Statement

    		PreparedStatement ptm = con.prepareStatement(query);
    		// 4 Execute Statement
    		ResultSet result = ptm.executeQuery();
    		
    		
    		ArrayList<Patient> plist = new ArrayList<>();
    		
    		while(result.next()) {
    			int pId = result.getInt(1);
    			String pFname = result.getString(2);
    			String pLname = result.getString(3);
    			Long pPhone = result.getLong(4);
    			String pAddress = result.getString(5);
    			String DocAssign=result.getString(6);
    			String pDisease=result.getString(7);
    			
    			
    		
    			Patient patient = new Patient(pId,pFname,pLname,pPhone,pAddress,DocAssign,pDisease);
    			plist.add(patient);
    		}
    		return plist;
	}
}
        
//       public String createpReport(String tableName) throws SQLException{
//    		String query="create table " + tableName
//    				+ "(pId int primary key,"
//    				+ "pFname varchar(55),"
//    				+ "pLname varchar(20),"
//    				+ "pPhone long,"
//    				+ "pAddress varchar(20),"
//    				+ "DocAssign varchar(20),"
//    				+ "pDisease varchar(20)"+
//    				")";
//       
//	
//        
//	}
	

	

	
//	public void createBill( int pId,
//		     String pFname,
//		     String pLName,
//		     String pPhone,
//		     String pAddress)  throws SQLException {
//
//				String query = "insert into customers Values ( " + pId + ",'" 
//				+ pFname + "', '" + pLName + "' ," +  pPhone+ " , '" + pAddress + "')";
//				
//				
//				// 2 get connection from singleton class jdbcConnection
//						Connection con = connect.getConnection();
//						// 3 Step Create Statement
//
//						PreparedStatement ptm = con.prepareStatement(query);
//						// 4 Execute Statement
//						ptm.execute();
//
//						System.out.println("Inserted Values Successfully ");
//						// 5 close connection
//						ptm.close();
//				
//			}
//	public void insertData(int pId, String pFname, String pLname,String pPhone,String pAddress) throws SQLException {
//
//		//String query = "insert into Patient Values (" + pId + ",'" + pFname +"','"  + pLname +"',"+pPhone+",'"+pAddress"'")";
//					
//
//	// 2 get connection from singleton class jdbcConnection
//		Connection con = connect.getConnection();
//		// 3 Step Create Statement
//
//		PreparedStatement ptm = con.prepareStatement(query);
//		// 4 Execute Statement
//		ptm.execute(query);
//
//		System.out.println("Inserted Values Successfully ");
//		// 5 close connection
//		ptm.close();
//
//	}

