package com.hospDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.entity.Doctor;
import com.jdbc_config.JdbcConnection;

public class DoctorDao {
	static JdbcConnection connect=new JdbcConnection();
	
	public String createTable(String tableName) throws SQLException{
		String query="create table " + tableName
				+ "(doctorId int primary key,"
				+ "docName varchar(55),"
				+ "docDepartment varchar(20))";
		
		Connection con = connect.getConnection();
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		// 4 Execute Statement
		ptm.execute(query);

		System.out.println("Table created " + tableName);
		// 5 close connection
		ptm.close();
		return "table created";

	}
	public void insertData(int doctorId, String docName, String docDepartment) throws SQLException {

		String query = "insert into Doctor Values (" + doctorId + ",'" + docName + "','"  + docDepartment + "')";

		// 2 get connection from singleton class jdbcConnection
		Connection con = connect.getConnection();
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		// 4 Execute Statement
		ptm.execute(query);

		System.out.println("Inserted Values Successfully ");
		// 5 close connection
		ptm.close();

	}
	
	public ArrayList<Doctor> FetchDoctor(String tableName) throws SQLException {

		String query = "select * from " + tableName;

		// 2 get connection from singleton class jdbcConnection
		Connection con = connect.getConnection();
		
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
		// 4 Execute Statement
		ResultSet result = ptm.executeQuery();
		
		
		ArrayList<Doctor> dlist = new ArrayList<>();
		
		
		while(result.next()) {
			
			int doctorId = result.getInt(1);
			String docName = result.getString(2);
			String docDepartment = result.getString(3);
		
			Doctor doctor = new Doctor(doctorId,docName,docDepartment);
			dlist.add(doctor);
		}

		// 5 close connection
		ptm.close();

		return dlist;

	}
	
	public void updatedoctorNameById(int doctorId, String docName) throws SQLException{
        // logic to update the name of a doctor by ID
        String query="update Doctor set docName='"+docName+"' where doctorId="+doctorId;
        	// 2 get connection from singleton class jdbcConnection
     		Connection con = connect.getConnection();
     		// 3 Step Create Statement

     		PreparedStatement ptm = con.prepareStatement(query);
     		// 4 Execute Statement
     		ptm.execute(query);

     		System.out.println("updated Values Successfully ");
     		// 5 close connection
     		ptm.close();
	
	}
	public void updatedocDepartmentById(int doctorId, String docdepartment) throws SQLException{
        // logic to update the name of a doctor by ID
        String query="update Doctor set docDepartment='"+docdepartment+"' where doctorId="+doctorId;
        	// 2 get connection from singleton class jdbcConnection
     		Connection con = connect.getConnection();
     		// 3 Step Create Statement

     		PreparedStatement ptm = con.prepareStatement(query);
     		// 4 Execute Statement
     		ptm.execute(query);

     		System.out.println("updated Values Successfully ");
     		// 5 close connection
     		ptm.close();
	
	}
	public void deletebyId(int doctorId,String tableName)throws SQLException{
			String query="DELETE FROM "+tableName+" where doctorId="+doctorId;
		// 2 get connection from singleton class jdbcConnection
			Connection con = connect.getConnection();
 		// 3 Step Create Statement

			PreparedStatement ptm = con.prepareStatement(query);
			
			
			
			// 4 Execute Statement
			int rowsAffected = ptm.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Deleted Row of id :  " + doctorId);
	        } else {
	            System.out.println("No records deleted. Please check if iId exists.");
	        }
 		// 4 Execute Statement
			ptm.execute(query);

			System.out.println("deleted Values Successfully ");
 		// 5 close connection
			ptm.close();
		
	}
	
	public void deletebyName(String docName,String tableName)throws SQLException{
		String query="DELETE FROM "+tableName+"Doctor where doctorId="+docName;
	// 2 get connection from singleton class jdbcConnection
		Connection con = connect.getConnection();
		// 3 Step Create Statement

		PreparedStatement ptm = con.prepareStatement(query);
 
		// 4 Execute Statement
		ptm.execute(query);

		System.out.println("deleted Successfully ");
		// 5 close connection
		ptm.close();
	
}
}
//	public void updatedoctorNameById(int doctorId, String docName) throws SQLException {
//	    // logic to update the name of a doctor by ID
//	    String query = "update Doctor set docName="+docName+" where doctorId="+doctorId;
//	    
//	    // 2 get connection from singleton class jdbcConnection
//	    Connection con = connect.getConnection();
//	    
//	    try (
//	        // 3 Step Create Statement
//	        PreparedStatement ptm = con.prepareStatement(query)
//	    ) {
//	    	 ptm.setString(1, docName);
//	         ptm.setInt(2, doctorId);
//
//	        // 5 Execute Statement
//	        int rowsAffected = ptm.executeUpdate();
//
//	        if (rowsAffected > 0) {
//	            System.out.println("Updated Values Successfully");
//	        } else {
//	            System.out.println("No rows were updated. Doctor ID not found.");
//	        }
//	    } finally {
//	        // 6 close connection in finally block to ensure it's always closed
//	        con.close();
//	    }
	


	

	
	
//	public void updateStrValues(String tableName, String colName, String newStr ,  int doctorId) throws SQLException {
//		String query = "Update " + tableName  
//				+ " set " 
//				+ colName +" = '" 
//				+ newStr    
//				+ "' where iId = " + doctorId ;
//		
//
//		// 2 get connection from singleton class jdbcConnection
//		Connection con = connect.getConnection();
//		// 3 Step Create Statement
//
//		PreparedStatement ptm = con.prepareStatement(query);
//		// 4 Execute Statement
//		ptm.execute();
//
//		System.out.println("Updated Values Successfully at column " + colName);
//		// 5 close connection
//		ptm.close();
//
//
//	}
//	
//	public void updateNumValues(String tableName, String colName, int newNum ,  int docId) throws SQLException {
//		String query = "Update " + tableName  
//				+ " set " 
//				+ colName + " =  ? " + " where docId = ? ";
//		
//
//		// 2 get connection from singleton class jdbcConnection
//		Connection con = connect.getConnection();
//		// 3 Step Create Statement
//
//		PreparedStatement ptm = con.prepareStatement(query);
//		
//		ptm.setInt(1, newNum);
//		ptm.setInt(2, docId);
//		
//		// 4 Execute Statement
//		int rowsAffected = ptm.executeUpdate();
//
//        if (rowsAffected > 0) {
//            System.out.println("Updated Values Successfully at column " + colName);
//        } else {
//            System.out.println("No records updated. Please check if iId exists.");
//        }
//		
// 
//		// 5 close connection
//		ptm.close();
//
//
//	}




	
	

