package com.hospcontroller;

import java.sql.SQLException;
import java.util.*;


import com.hospService.DocService;
import com.hospService.PatientService;

public class DoctorController {

		static DocService ds=new DocService();
		static PatientService ps=new PatientService();
		
		public static void OpenChoices() throws SQLException {
			
			Scanner sc = new Scanner(System.in);
			
//			1. New Admission
//			2. Update Patient
//			3. View Patients
//			4. Add New Doctor
//			5. View Doctors
//			6. Update Doctors
//			7. Patient Reports
//			8. Search Patient
//			0. Exit
			System.out.println();
			System.out.println("What do you want to do ?");
			System.out.println("1.Add patient");//hora hai
			System.out.println("2.update patient");//hora hai
			System.out.println("3.view Patient");// happening
			System.out.println("4.Add new Doctor");//happening
			System.out.println("5.view Doctors");//happening
			System.out.println("6.Update Doctors");//aadha
			System.out.println("7.Patient Reports");//nope
			System.out.println("8.Search patient");//nope
			System.out.println("0.Exit");//horay
			int choice = sc.nextInt();
			sc.nextLine();
			String tablename1;
			switch (choice) {
			case 1:
				System.out.println();
				System.out.println("Enter patient details to be created : ");
				System.out.println("Enter id");
				int pId=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter first name");
				String pFname = sc.nextLine();
//				sc.nextLine();
				System.out.println("Enter last name");
				String pLname=sc.nextLine();
				System.out.println("Enter phonenumber");
				Long pPhone=sc.nextLong();
				System.out.println("Enter Address");
				sc.nextLine();
				String pAddress=sc.nextLine();
				System.out.println("which Doctor you want ");
				String DocAssign=sc.nextLine();
				System.out.println("which disease you are suffering from");
				String pDisease=sc.nextLine();
				
				ps.ReportpData(pId, pFname, pLname, pPhone, pAddress, DocAssign, pDisease);
				OpenChoices();
				break;
				
			case 2:
				System.out.println("update patient : ");
				System.out.println();
				System.out.println("Enter patient pId");
				int pId1=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter first Name");
				String pFname1=sc.nextLine();
				sc.nextLine();
				System.out.println("Enter last name");
				String pLname1=sc.nextLine();
				sc.nextLine();
				
				ps.updatepNamebyid(pId1, pFname1, pLname1);
				
				
				OpenChoices();
				break;	
				
			case 3:
				System.out.println("view Patient:");
				System.out.println();
				System.out.println("Enter table name");
				String tableName2=sc.nextLine();
				ps.getReport(tableName2);
				OpenChoices();
				break;
			case 4:
				System.out.println("Add new doctor");
				System.out.println("Enter Id");
				int dId=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter doctorname");
				String dname=sc.nextLine();
				sc.nextLine();
				System.out.println("enter doctor department");
				String ddepartment=sc.nextLine();
				ds.insertData(dId, dname, ddepartment);
				OpenChoices();
				break;
				
			case 5:
				System.out.println("view Doctors");
				System.out.println("enter table name");
				tablename1=sc.nextLine();
				
				ds.FetchDoctor(tablename1);
				OpenChoices();
				
				break;
			case 6:
				System.out.println("update Doctors");
				System.out.println();
				System.out.println("Enter doctor id");
				int doctorId = sc.nextInt();

				// Consume the newline character left in the buffer
				sc.nextLine();

				System.out.println("Enter new name of doctor");
				String docName = sc.nextLine();
				ds.updatedoctorNamebyId(doctorId, docName);
				OpenChoices();
				break;

			case 7:
				System.out.println("  Patient Reports ");
				System.out.println("Enter patient id");
				
				int id2 = sc.nextInt();
				System.out.println();
				ps.getpReport(id2);
				OpenChoices();
				break;
			case 8 :
				System.out.println("Search  Patient ");
				System.out.println("Enter patient id");
				int id = sc.nextInt();
				System.out.println();
				ps.getpReport(id);
				OpenChoices();
				break;
				
			case 0:
				System.out.println("Exiting Program , Thank you for your service");
				return;
			default:
				System.out.println("Invalid Option Please Try Again");
				break;
			}
			
		}
				
			
		// TODO Auto-generated method stub
		//ds.createTable("Doctor");
		//ds.insertData(101,"doc1", "physiotherapy");
		
		public static void main(String args[])throws SQLException {
			//doctors ka sab.
			
		//ds.insertData(104,"doc2", "dentist");
			
			//ds.deletebyId(104, "doctor");
			OpenChoices();
		}
			//ds.updatedoctorNameById(101, "Dr.abc shah");
			//ps.createpTable("Patient");
			//ds.updatedocDepartmentById(104, "Neurology");
			
			
			
			//patient ka sab.
			//ds.createTable("Patient");
			
		}
		
		
//		public static void updateStrValues() throws SQLException {
//			Scanner sc = new Scanner(System.in);
//			System.out.println();
//			System.out.println("Enter TableName : ");
//			String tb1 = sc.nextLine();
//			
//			System.out.println("Enter colName where change to be done : ");
//			String colName = sc.nextLine();
//
//			System.out.println("Enter newValue to be set : ");
//			String newStr = sc.nextLine();
//			
//			
//			System.out.println("Enter iId : ");
//			int iId = sc.nextInt();
//			sc.nextLine();
//
//			System.out.println();
//			
//			ds.updateStrValues(tb1, colName, newStr, iId);
//			OpenRestaurant();
//		}
//		
//		public static void updateNumValues() throws SQLException {
//			Scanner sc = new Scanner(System.in);
//			System.out.println();
//			System.out.println("Enter TableName : ");
//			String tb1 = sc.nextLine();
//			
//			System.out.println("Enter colName where change to be done : ");
//			String colName = sc.nextLine();
//
//			System.out.println("Enter newValue to be set : ");
//			int newNum = sc.nextInt();
//			sc.nextLine();
//			
//			System.out.println("Enter iId : ");
//			int iId = sc.nextInt();
//			sc.nextLine();
//
//			System.out.println();
//			
//			ds.updateNumValues(tb1, colName, newNum, iId);
//			OpenRestaurant();
//		}
//		
//
//		private static void OpenRestaurant() throws SQLException {
//			// TODO Auto-generated method stub
//			
//		}
	
	

