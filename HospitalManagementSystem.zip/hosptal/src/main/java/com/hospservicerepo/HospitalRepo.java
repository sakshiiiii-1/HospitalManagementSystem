package com.hospservicerepo;

import java.sql.SQLException;

public interface HospitalRepo {
	
	
		public void createTable(String tableName) throws SQLException;
		
		public void insertData(int doctorId, String docName, String docDepartment) throws SQLException ;
		
		public void FetchDoctor(String tableName) throws SQLException;
		
		public void updatedoctorNameById(int doctorId, String docName) throws SQLException;
		
		public void updatedocDepartmentById(int doctorId, String docdepartment) throws SQLException;
		
		public void deletebyId(int doctorId,String tableName)throws SQLException;
		public void deletebyName(String docName,String tableName)throws SQLException;
		
		
		
		
		
		
		
//		public void updateStrValues(String tableName, String colName, String newStr, int iId) throws SQLException;
//		
//		public void updateNumValues(String tableName, String colName, int newNum, int doctorId) throws SQLException;
}
