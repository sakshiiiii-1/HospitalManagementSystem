package com.hospservicerepo;

import java.sql.SQLException;
import java.util.ArrayList;

import com.entity.Patient;

public interface PatientRepo {
	
		public void CreatepTable(String tableName) throws SQLException;
	
		public void ReportpData(int pId, String pFname ,
			String pLname,long pPhone,String pAddress,
			String DocAssign, String pDisease) throws SQLException;
		
		public ArrayList<Patient> getpReport(int pId) throws SQLException ;

		public void updatepNamebyid(int pId,String pFname,String pLname)throws SQLException;
		
		public void deletepbyId(int pId,String tableName)throws SQLException;
		
		public ArrayList<Patient> getReport(String tableName) throws SQLException;
}
